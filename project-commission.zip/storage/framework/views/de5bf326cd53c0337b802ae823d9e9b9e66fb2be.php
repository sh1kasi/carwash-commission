<!-- Modal -->



<div class="modal fade" id="transactionForm" role="dialog" aria-labelledby="transactionFormLabel" aria-hidden="true">
  <div class="modal-dialog" style="max-width: 700px" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="transactionFormLabel">TAMBAH TRANSAKSI</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"></span>
        </button>
      </div>
      <div class="modal-body">

        <ul id="err_list"></ul>

        <div class="form-group pb-1 input-daterange">
          <label for="exampleInputEmail1"><b>Tanggal</b></label> <br>
          <input style="width: 45%;" value="<?php echo e($currentDate); ?>" class="form-control mt-2 mb-2" id="date" style="text-transform: uppercase;" aria-describedby="emailHelp" name="date" />
        </div>
        <div class="form-group pb-1">
          <label for="exampleInputEmail1"><b>NO PLAT KENDARAAN</b></label> <br>
          <select style="width: 100%;" class="form-control mt-2 mb-2" id="nopol" style="text-transform: uppercase;" aria-describedby="emailHelp" name="nopol"></select>
          
        </div>
        
        <div class="row pt-1">
          <label class="form-check-label mt-2" style="font-size: 15px" for="defaultCheck1"><b>LAYANAN</b></label>
          <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
            <div class="form-group mt-1 col-md-6">
              <input class="form-check-input cbservice" data-commission="<?php echo e($service->commission_value); ?>" data-type="<?php echo e($service->type_commission); ?>" type="checkbox" name="servicesCheckbox" onclick="servicesCheckbox(<?php echo e($service->id); ?>)" value="<?php echo e($service->id); ?>" id="servicesCheckbox">
              <label class="form-check-label ps-2" style="font-size: 15px" for="defaultCheck1"><?php echo e($service->service); ?> (Rp <?php echo number_format($service->price,0,',','.'); ?>)</label>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php if(count($bundle) != 0): ?>
              
              <label class="form-check-label mt-3" style="font-size: 15px" for="defaultCheck1"><b>LAYANAN BUNDLING</b></label>
              
              <?php
                  $bundling_price = 0;
                  $product_array = [];
                  $bundleVal = 0;
              ?>
                  <?php $__currentLoopData = $bundle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bundling): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="form-group col-md-6">
                    <input class="form-check-input cbbundling" type="checkbox" name="bundlingsCheckbox" onclick="servicesCheckbox(<?php echo e($bundling->id); ?>)" value="<?php echo e($bundling->id); ?>" id="bundlingsCheckbox">
                    <label class="form-check-label ps-2" style="font-size: 15px" for="defaultCheck1"><?php echo e($bundling->name); ?> (Rp <?php echo number_format($bundling->total_price,0,',','.'); ?>)
                      <?php $__currentLoopData = $bundling->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                      <ul style="margin-bottom: 0px !important">
                        
                        <input type="hidden" id="product_id" value="<?php echo e($item->id); ?>">
                        <li><?php echo e($item->service); ?></li>
                      </ul>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </label>
                        </div>
                        
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </div>

        <div class="row pt-2 pb-3" style="border-bottom: 1px solid #c5bebefa"> 
          <label class="form-check-label mt-3" style="font-size: 15px" for="defaultCheck1"><b>PENGGARAP</b></label>
          <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
            <div class="form-group mt-1 col-md-6">
              <input class="form-check-input cbemployee" name="employee" type="checkbox" value="<?php echo e($employee->id); ?>" id="employee">
              <label class="form-check-label ps-2" style="font-size: 15px" for="defaultCheck1"><?php echo e($employee->name); ?></label>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="d-flex justify-content-between pt-2">
          <div class="total"><b>Total Harga: </b></div>
          <div id="amount" class="text-danger">Rp <?php echo number_format(0,0,',','.'); ?></div>
          
        </div>

      </div>
      <div class="modal-footer">
        <button type="submit" id="submit" class="btn btn-primary">Simpan Transaksi</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<input type="hidden" value="" id="total_price">
<input type="hidden" value="" id="transaction_id">

<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>


<script>


  // console.log($(".cbbundling").val());

var selectOption = {
        placeholder: "Pilih Plat Nomor",
        minimumInputLength: 1,
        allowClear: true,
        tags:true,
        theme: "bootstrap-5",
        ajax: {
            url:  "/transaction-select",
            dataType: "json",
            delay: 250,
            type: "POST",
            headers: {
                'X-CSRF-TOKEN': token,
            },
            data: function (params) {
                return {
                    search: params.term,
                    // branch_id: $('#branch_id').val(),
                };
            },
            processResults: function (data) {
                var select2Data = $.map(data, function (obj) {
                    obj.id = obj.customer;
                    obj.text = `${obj.customer}`;
                    return obj;
                });
                return {
                    results: select2Data,
                };
            },
            cache: true,
        },
    };

    $('#nopol').select2(selectOption);



  function bundlingsCheckbox(id) {
    // var bundlingArray = [];
    // $(".cbbundling:checkbox:checked").each(function () {
    //   // bundlingArray.push($(this).val());
      
    // });

      

      if ($(".cbbundling:checkbox").is(':checked')) {
        var bundleVal = $(".cbbundling:checkbox:checked").val();
        var bundleArray = bundleVal.split(',')
        console.log(bundleVal);
      } else {
        var bundleArray = [];
        // console.log(bundleArray);
      }

      $.ajaxSetup({
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
      $.ajax({
        type: "post",
        url: "/transaction-total",
        data: {
          // serviceArray: serviceArray,
          bundling: bundleArray,
        },
        dataType: "json",
        success: function (response) {
          if (bundleArray.length > 0) {
            $("#amount").html(`Rp ${response.total_price.toLocaleString("id-ID")}`);
            $("#total_price").val(response.total_price);
          } else {
            $("#amount").html(`Rp 0`);
          }
        }
      });

    // var bundleVal = $(".cbbundling:checkbox:checked").val();
    // var bundleArray = bundleVal.split(',')


  }

  function servicesCheckbox(id) {

    var serviceArray = [];
    $(".cbservice:checkbox:checked").each(function () {
      serviceArray.push($(this).val());
    });


    if ($(".cbbundling:checkbox").is(':checked')) {
      console.log('not checked');
        var bundleArray = [];
        $(".cbbundling:checkbox:checked").each(function () {
          bundleArray.push($(this).val());
        });
        // var bundleVal = $(".cbbundling:checkbox:checked").val();
        // var bundleArray = bundleVal.split(',')
        // console.log(bundleArray);
      } else {
        console.log('checked');
        var bundleArray = [];
        // console.log(bundleArray);
      }

      console.log(bundleArray);



      $.ajaxSetup({
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
      $.ajax({
        type: "post",
        url: "/transaction-total",
        data: {
          serviceArray: serviceArray,
          bundling: bundleArray,
        },
        dataType: "json",
        success: function (response) {
          $("#amount").html(`Rp ${response.total_price.toLocaleString("id-ID")}`);
          $("#total_price").val(response.total_price);
          // if (serviceArray.length > 0) {
          // } else {
          //   $("#amount").html(`Rp 0`);
          // }
        }
      });
  } 

  $(document).ready(function () {

    $("#submit").click(function (e) { 
      e.preventDefault();

      var nopol = $("#nopol").val();
      var service = $("#servicesCheckbox").val();
      var employee = $("#employee").val();
      var date = $("#date").val();
      var total_price = $("#total_price").val();
      var commission = $("#servicesCheckbox").data('commission');
      var commiss_check = $("#servicesCheckbox").data('type');

      console.log(commiss_check);

      var serviceArray = [];
      var employeeArray = [];

      
    $(".cbservice:checkbox:checked").each(function () {
      serviceArray.push($(this).val());
    });

    $(".cbemployee:checkbox:checked").each(function () {
      employeeArray.push($(this).val());
    });
    
    if ($(".cbbundling:checkbox").is(':checked')) {
      var bundleArray = [];
        $(".cbbundling:checkbox:checked").each(function () {
          bundleArray.push($(this).val());
        });  
      // var bundleVal = $(".cbbundling:checkbox:checked").val();
        // var bundleArray = bundleVal.split(',')
        // // console.log(bundleArray);
      } else {
        var bundleArray = [];
        // console.log(bundleArray);
      };

      // console.log(serviceArray);
      // return false;

      if (bundleArray.length < 1 && serviceArray.length < 1) {
        $("#err_list").html("");
        $("#err_list").addClass("alert alert-danger");
        $("#err_list").append(`<li style="margin-left: 15px;">Select at least one of the service</li>`);
      } else {

      

  

      $.ajaxSetup({
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });

      $.ajax({
        type: "post",
        url: "/transaction-store",
        data: {
          nopol: nopol,
          service: serviceArray,
          employee: employeeArray,
          total_price: total_price,
          date: date,
          bundling: bundleArray,
          commiss_check: commiss_check,
        },
        dataType: "json",
        success: function (response) {

          // console.log(response);

          if (response.status == 400) {
            // console.log(bundleArray);
            $("#err_list").html("");
            if (bundleArray.length == 0 && serviceArray.length == 0) {
              $("#err_list").append(`<li style="margin-left: 15px;">Select at least one of the service</li>`);
            }
            $("#err_list").addClass('alert alert-danger');
            $("#err_list").append(`<li style="margin-left: 15px;">${response.errors.nopol[0]}</li>`);
            $("#err_list").append(`<li style="margin-left: 15px;">${response.errors.employee[0]}</li>`);
            // $(response.errors).each(function (key, err_values) {
            //   console.log(err_values);
            // });
          } else {
                 
              if (response.tambahan == true) {
                // window.location.reload();
                $("#transaction_id").val(response.data.id);
                $("#extra_transaction_id").val(response.data.id);
                // $(response.worker).each(function (key, extra) {
                //   $("#extraWorks").append(`
                  
                //   <input type="checkbox" name="inputExtra" class="cbextra ms-2" onclick="extraWorkers(${extra.id})" value="${extra.id}" id="inputExtra">
                //   <label for="inputExtra" id="extraName">${extra.name}</label>  
                //   `);
                // });
                $('#extraWorksModal').modal('show');
                var html = ''
                var extraArray = [];
                $(response.extra_product).each(function (index, ex_product) {
                  // console.log(ex_product);
                  extraArray.push(ex_product.id);
                  console.log(extraArray);
                  html += `
                        <h5 class="modal-title" id="extraWorksModalLabel">${ex_product.service}</h5>
                        <input type="hidden" id="product" name="product_id[]" value="${ex_product.id}">
                  `
                  $(response.worker).each(function (key, extra) {
                    console.log(extra.name);
                    html += `
                      <input type="checkbox" name="employee_id_${index}[]" class="cbextra ms-2" onclick="extraWorkers(${extra.id} ,${ex_product.id})" value="${extra.id}" id="inputExtra">
                      <label id="extraName">${extra.name}</label>  
                      `
                      $("#extraArray").val(extraArray);                
                    });
                    });
                  $("#pekerjaExtra").append(html);
          
                  
                // $(response.extra_product).each(function (key, extra) {
                  // $("#extraWorksModalLabel").html(`Pilih penggarap ${response.extra_product}`);
                // });
    
                $('#transactionForm').modal('hide');
    
    
    
    
              } else {
    
                
                $('#transactionForm').modal('hide');
                $('#CommissionModal').modal('show');
                // window.location.reload();
    
                $.ajaxSetup({
                  headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  }
                });
    
              $.ajax({
                  type: "post",
                  url: "transaction-detail",
                  data: {
                      id: response.data.id
                  },
                  dataType: "json",
                  success: function (response) {
                    console.log(response);
                      // console.log($("#transaction_id").val());
                      $("#tgl_transaksi").html(`Tanggal Transaksi: &nbsp; ${response.tanggal_transaksi}`);
                $("#plat_nomor").html(`NOPOL: &nbsp; ${response.transaction.customer}`);
                $("#service").html(`Layanan: <ul id="buyservice"></ul>`);
                $(response.grouped_product).each(function (key, grouped) {
                  console.log(grouped);
                    $("#buyservice").append(`<li><b>${grouped.employee_products.service} &nbsp; &nbsp; (Rp ${grouped.employee_products.price.toLocaleString("id-ID")})</b></li>`);
                    // var service = buy_service.service;
                });
                $("#total_harga").html(`Total: &nbsp; Rp ${response.transaction.total_price.toLocaleString("id-ID")}`);
                $("#penggarap").html("");
    
                console.log(service);
    
                $(response.worker).each(function (key, workers) {

                      var append = `<tr><td>${workers.worker}</td><td><ul>`
                      var services = ''
                      // var commission = ''
                      var total_commission = 0
                      $(workers.services).each(function (key, product) {
                          total_commission += product.commission
                          services = services +
                              `<li>${product.employee_products.service}</li>`;
                          console.log(`<li>${product.employee_products.service}</li>`);
                          // commission = commission + ``;
                      });
                      append = append + services + '</ul></td><td>' + 'Rp ' + total_commission
                          .toLocaleString('id-ID') + '</td></tr>'
                      
                      $("#penggarap").append(append);
                      $("#total_komisi").html(
                    `Rp ${response.transaction.comission.toLocaleString('id-ID')}`);
                
                });
    
                      // if (response.commiss_check > 0) {
                      //   $(response.worker).each(function (key, workers) {
    
                      //     $("#penggarap").append(`<tr>
                      //                                 <td>${workers.name} ${workers.pivot.status == 'extra' ? `(${response.extra_product})` : ''}</td>
                      //                                 <td>Rp ${workers.pivot.commission.toLocaleString("id-ID")}</td>
                      //                             </tr>`);
                      //     $("#total_komisi").html(`Rp ${response.transaction.comission.toLocaleString('id-ID')}`);
                      // });
                      // } else {
                      //   $(response.worker).each(function (key, workers) {
                      //     $("#penggarap").append(`<tr>
                      //                                 <td>${workers.name}</td>
                      //                                 <td>Rp ${response.commission.toLocaleString('id-ID')}</td>
                      //                             </tr>`);
                      //     $("#total_komisi").html(`Rp ${response.transaction.comission.toLocaleString('id-ID')}`);
                      // });
                      // }
                    
    
                    }
                  });
                  
                }
            
            
          }

          
        } 
      });
      
    }
      
    });

  });
  
</script><?php /**PATH C:\laragon\www\commission-project\resources\views/admin/adminModal/transactionForm.blade.php ENDPATH**/ ?>