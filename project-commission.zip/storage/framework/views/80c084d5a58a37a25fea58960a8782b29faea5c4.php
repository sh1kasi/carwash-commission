<!DOCTYPE html>
<html>



<head>
    <style>
        #customers {
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        #customers td,
        #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        #customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #customers tr:hover {
            background-color: #ddd;
        }

        #customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #04AA6D;
            color: white;
        }

        h1 {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 22px;
        }

    </style>
</head>

<body>

    <?php if($from == null && $to == null): ?>
        <h1>Detail Komisi <?php echo e($employee->name); ?> (<?php echo e($tanggal_terlama); ?> &nbsp; - &nbsp; <?php echo e($tanggal_terbaru); ?>)</h1>
    <?php else: ?>
    <h1>Detail Komisi <?php echo e($employee->name); ?> (<?php echo e($from); ?> &nbsp; - &nbsp; <?php echo e($to); ?>)</h1>
    <?php endif; ?>

    
    <table id="customers">
        <thead>
            <tr>
                <th>#</th>
                <th>Nopol</th>
                <th>Layanan yang dikerjakan</th>
                <th>Tanggal</th>
                <th>Komisi</th>
                
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            $total_commission = 0;
            $total_kasbon = 0;
            ?>

            <?php $__currentLoopData = $employee_kasbon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kasbon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $total_kasbon += $kasbon->nominal;
                    $sisa_nominal = $kasbon->kasbon_maksimal - $total_kasbon;
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php $__currentLoopData = $daterange; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <tr id="tbody">
                <td><?php echo e($no++); ?></td>
                
                <td><?php echo e($data->transactions->customer); ?></td>
                <td>
                    <ul>
                        <?php
                        $row_commission = 0;
                        // $commission_total = 0;
                        ?>
                        
                        <?php $__currentLoopData = $transaction_product->where('transaction_id', $data->transactions->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $row_commission += $product->commission;
                        // $commission_total +=/ $product->commission;
                        // dd($commission_total)
                        ?>
                        <li><?php echo e($product->employee_products->service); ?> (Rp <?php echo number_format($product->commission,0,',','.'); ?>)</li>
                        <?php
                        $total_commission += $product->commission;
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </ul>
                </td>
                <td style="text-align: center">
                    <?php echo e($data->transactions->created_at->translatedFormat('j F Y - H:i:s')); ?>

                </td>
                
                
                <td style="text-align: center">Rp <?php echo number_format($row_commission,0,',','.'); ?> </td>
            </tr>
            

            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3" text-align="center"></td>
                <td class="table-primary" style="text-align: center">Total : </td>
                <td class="table-primary" style="text-align: center">Rp <?php echo number_format($total_commission,0,',','.'); ?></td>
            </tr>
            <th class="text-align: center;" colspan="5  ">Kasbon
                <tr>
                    <td colspan="1" text-align="center"></td>
                    <td class="table-primary" style="text-align: center">Total Kasbon : </td>
                    <td class="table-primary" style="text-align: center">Rp <?php echo number_format($total_kasbon,0,',','.'); ?></td>
                    <td class="table-primary" style="text-align: center">Sisa Kasbon</td>
                    <td class="table-primary" style="text-align: center">Rp <?php echo number_format($sisa_nominal,0,',','.'); ?></td>
                </tr>
            </th>
        </tfoot>
    </table>

</body>

</html>
<?php /**PATH E:\xampp\htdocs\project-commission\resources\views/admin/employeeDetailExportPDF.blade.php ENDPATH**/ ?>