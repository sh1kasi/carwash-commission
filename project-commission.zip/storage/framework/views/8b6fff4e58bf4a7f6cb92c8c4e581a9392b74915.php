

<?php $__env->startSection('content'); ?>
    
<div class="page-content">
    <div class="main-wrapper">
        <div class="row">
            <div class="col">

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ul>
                                <li><?php echo e($error); ?></li>
                            </ul>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Tambah Layanan</h5>
                        <form action="<?php echo e(route('bundle.post')); ?>" method=post>
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                              <label for="exampleInputEmail1" class="form-label">Nama Bundle</label>
                              <input type="text" id="name" value="" name="name" class="form-control" id="exampleInputEmail1" placeholder="Masukkan Nama Bundle" aria-describedby="emailHelp">
                            </div>
                           
                            <div class="row pt-1" id="bundling-checkbox">
                                <label class="form-check-label mt-2" style="font-size: 15px" for="defaultCheck1">Layanan</label>
                                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                                      <div class="form-group mt-1 col-md-4 mb-3">
                                        <input class="form-check-input cbservice " type="checkbox" name="servicesCheckbox[]" value="<?php echo e($service->id); ?>" id="servicesCheckbox">
                                        <label class="form-check-label ps-2" style="font-size: 15px" for="defaultCheck1"><?php echo e($service->service); ?> (Rp <?php echo number_format($service->price,0,',','.'); ?>)</label>
                                      </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                            
                            <button type="submit" id="submit" class="btn btn-primary mt-3">Submit</button>
                          </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\project-commission\resources\views/admin/bundlingForm.blade.php ENDPATH**/ ?>