<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>scanqr</title>
</head>
<body>
    <div class="scanqr">
        
        
        <div class="scanmobil">
            <h1>Link Mobil</h1>
            <p><?php echo DNS2D::getBarcodeHTML(route('customer.mobil'), 'QRCODE'); ?></p>
        </div>
        
    </div>
</body>
</html><?php /**PATH E:\xampp\htdocs\project-commission\resources\views/scanqr.blade.php ENDPATH**/ ?>