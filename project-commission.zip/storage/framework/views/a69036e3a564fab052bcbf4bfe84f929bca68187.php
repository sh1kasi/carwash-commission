<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <div class="qr row">
        <div class="col-md-6">
            <p>LINK MOBIL</p>
            <p><?php echo DNS2D::getBarcodeSVG('/customer/mobil?kendaraan=mobil', 'QRCODE', 10,10); ?></p>
        </div>
        
    </div>
</body>
</html><?php /**PATH E:\xampp\htdocs\project-commission\resources\views/tester/scanqr.blade.php ENDPATH**/ ?>