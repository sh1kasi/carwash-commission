

<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" integrity="sha512-3pIirOrwegjM6erE5gPSwkUzO+3cTjpnV9lexlNZqvupR64iZBnOOTiiLPb9M36zpMScbmUNIcHUqKD47M719g==" crossorigin="anonymous" referrerpolicy="no-referrer" />




<div class="page-content">
    <div class="main-wrapper">
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Detail Pegawai</h5>

                        <div class="daterange input-daterange d-flex justify-content-around pt-3 mb-3">
                            <form class="d-flex justify-content-between" id="date_filter" action="" method="get">
                                <div class="from_date d-flex">                              
                                    <p style="width: 155px">Dari tanggal: </p>
                                    <input type="text" class="form-control mb-3" name="from" value="<?php echo e(Request()->query('from')); ?>" id="from_date">
                                </div>
                                <div class="to_date d-flex ms-5">
                                    <p style="width: 250px">Hingga tanggal: </p>
                                    <input type="text" class="form-control mb-3" name="to" value="<?php echo e(Request()->query('to')); ?>" id="to_date">
                                    <button class="btn btn-primary mb-3 ms-2" type="button" id="search_date"><i class="fa fa-search" aria-hidden="true"></i></i></button>
                                    <button class="btn btn-success mb-3 ms-2" type="button" id="print_pdf"><i class="fa fa-download" aria-hidden="true"></i></button>
                                    <a href="/employee/detail/<?php echo e($id); ?>" class="btn btn-warning mb-3 ms-2" type="button"><i class="fa fa-refresh" aria-hidden="true"></i></a>
                                </div>
                            </form>
                        </div>

                        
                        <table id="Tables123" class="display table table-bordered" style="width:100%" align="center">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Nopol</th>
                                    <th>Layanan yang dikerjakan</th>
                                    <th>Tanggal</th>
                                    <th>Komisi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $no = 1;
                                    $total_commission = 0;
                                ?>
                                <?php $__currentLoopData = $transaction_employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                
                                    
                                        <tr id="tbody">
                                            <td><?php echo e($no++); ?></td>
                                            
                                            <td><?php echo e($data->transactions->customer); ?></td>
                                            <td>
                                                <ul>
                                                    <?php
                                                        $row_commission = 0;
                                                        // $commission_total = 0;
                                                    ?>
                                                    
                                                    <?php $__currentLoopData = $transaction_product->where('transaction_id', $data->transactions->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            $row_commission += $product->commission;
                                                            // $commission_total +=/ $product->commission;
                                                            // dd($commission_total)
                                                        ?>
                                                        <li><?php echo e($product->employee_products->service); ?> (Rp <?php echo number_format($product->commission,0,',','.'); ?>)</li>
                                                        <?php
                                                            $total_commission += $product->commission;
                                                        ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                </ul>
                                            </td>
                                            <td style="text-align: center">
                                                
                                                <?php echo e($data->transactions->created_at->translatedFormat('j F Y - H:i:s')); ?>

                                            </td>
                                                
                                            
                                                
                                            <td style="text-align: center">Rp <?php echo number_format($row_commission,0,',','.'); ?></td>
                                            
                                        </tr>
                                        
                                            
                                    
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="3" text-align="center"></td>
                                    <td class="table-primary" style="text-align: center">Total : </td>
                                    <td class="table-primary" style="text-align: center">Rp <?php echo number_format($total_commission,0,',','.'); ?></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>      
            </div>
        </div>
    </div>
</div>

<input type="hidden" value="<?php echo e($id); ?>" id="employee_id">

<script src="https://cdn.jsdelivr.net/npm/toastr@2.1.4/toastr.min.js"></script>



<script>
    $(document).ready( function () {

        $("#search_date").click(function (e) { 
            e.preventDefault();
            
            var from_date = $("#from_date").val();
            var to_date = $("#to_date").val();
            var id = $("#employee_id").val();
            if (from_date != '' && to_date != '') {
             document.getElementById("date_filter").submit();
            } else {
                toastr.error("Harap isi kedua tanggal tanggal tersebut!");
            }

        });

        $('.input-daterange').datepicker({
            todayBtn: 'linked',
            format: 'yyyy-mm-dd',
            autoclose: true,
        });

        $('#Tables123').DataTable({});

        $("#print_pdf").click(function (e) { 
            e.preventDefault();
            
            var employee_id = $("#employee_id").val();

            var from = $("#from_date").val();
            var to = $("#to_date").val();

            // alert(from);

            // if (from == null) {
            //     var from = {!! Request()->query('from')};
            // }

            // if (to == null) {
            //     var to = {!! Request()->query('to')};
            // }

            // alert(from  to);


            window.open(`/employee-detail/cetak?employee_id=${employee_id}&from=${from}&to=${to}`);

            // $.ajax({
            //     type: "get",
            //     url: "/employee-detail/cetak",
            //     data: {
            //         employee_id: employee_id,
            //         from: from,
            //         to: to,
            //     },
            //     dataType: "dataType",
            //     success: function (response) {
                    
            //     }
            // });

        });

        // $("#search_date").click(function (e) { 
        //     e.preventDefault();

        //     console.log('clicked');
            
        //     var from_date = $("#from_date").val();
        //     var to_date = $("#to_date").val();
        //     var employee_id = $("#employee_id").val();

        //     console.log(employee_id);

        //     $.ajaxSetup({
        //         headers: {
        //             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        //         }
        //     });

        //     $.ajax({
        //         type: "get",
        //         url: `/employee/detail/${employee_id}`,
        //         data: {
        //             from_date: from_date,
        //             to_date: to_date,
        //             id: employee_id,    
        //         },
        //         dataType: "json",
        //         success: function (response) {

        //             window.location.reload();
        //             console.log(response);
        //             $("#tbody").remove();
        //         }
        //     });
             
        //     console.log(from_date);
        //     console.log(to_date);

        // });


    });
</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\project-commission\resources\views/admin/employeeDetail.blade.php ENDPATH**/ ?>