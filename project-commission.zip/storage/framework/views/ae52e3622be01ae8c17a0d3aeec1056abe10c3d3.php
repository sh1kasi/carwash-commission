

<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" integrity="sha512-3pIirOrwegjM6erE5gPSwkUzO+3cTjpnV9lexlNZqvupR64iZBnOOTiiLPb9M36zpMScbmUNIcHUqKD47M719g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<style>
    td {
        align-content: center;
    }
</style>



<div class="page-content">
    <div class="main-wrapper">
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Transaksi Terbaru
                            
                        </h5>
                        
                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" style="left: 450px; position:absolute; top: 30px"></button>
                                    <div class="form-group pb-1">
                                        <label for="exampleInputEmail1"><b>NO PLAT KENDARAAN</b></label> <br>
                                      </div>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group pb-1">
                                        <div class="mb-3">
                                            
                                            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                            
                                          </div>
                                        
                                        
                                      </div>
                                </div>
                                <div class="modal-footer">
                                
                                <button type="button" class="btn btn-primary">Simpan Perubahan</button>
                                </div>
                            </div>
                            </div>
                        </div>

                        <table id="transaksiTable" class="display table table-striped table-hover"  style="width:100%; margin-top: 40px; text-align:center">
                            <thead>
                                <tr>
                                    <th class="text-center">#</th>
                                    <th class="text-center">Nopol</th>
                                    <th class="text-center">Jenis Kendaraan</th>
                                    <th class="text-center">Keterangan</th>
                                    <th class="text-center">Tanggal</th>
                                </tr>
                            </thead>
                            
                        </table>
                </div>      
            </div>
        </div>
    </div>
</div>

<script> 


    $(document).ready(function () {
        // $('#nopol').select2(selectOption); 
        
        $.ajaxSetup({
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
        });

        // load_data();

        
        // function load_data(from_date = '', to_date = '') {
            
            $('#transaksiTable').DataTable({
                processing: true,
                serverSide: true,
                filter: true,
                searching: false,
                
                ajax: {
                type: 'GET',
                url: '/transaksi/json',
                // data: {
                // from_date: from_date,
                // to_date: to_date,
                // }
              },
              columns: [
                  {data: 'DT_RowIndex', name: '#'},
                  {data: 'nopol', name: 'nopol'},
                  {data: 'jenis_kendaraan', name: 'jenis_kendaraan'},
                  {data: 'keterangan', name: 'keterangan'},
                  {data: 'date', name: 'date'},
                ]
            });
            
        // }
        
    });

    function transactionInput(id) {
        var tanggal = $(`#pending${id}`).attr('data-date');
        var nopol = $(`#pending${id}`).attr('data-nopol');
        var transaksi_id = $(`#pending${id}`).attr('data-transaksiID');

        console.log(tanggal);
        console.log(nopol);

        window.location.href = (`/transaction?tanggal=${tanggal}&nopol=${nopol}&transaksi_id=${transaksi_id}`);


    }



</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\project-commission\resources\views/Admin/transaksiIndex.blade.php ENDPATH**/ ?>