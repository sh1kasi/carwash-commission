

<?php $__env->startSection('content'); ?>
    
<div class="page-content">
    <div class="main-wrapper">
        <div class="row">
            <div class="col">

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ul>
                                <li><?php echo e($error); ?></li>
                            </ul>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Tambah Layanan</h5>
                        <form action="/employee/update/<?php echo e($employee->id); ?>" method=post>
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                              <label for="exampleInputEmail1" class="form-label">Nama Pegawai</label>
                              <input type="text" id="name" value="<?php echo e($employee->name); ?>" name="name" class="form-control" id="exampleInputEmail1" placeholder="Masukkan Nama Pegawai" aria-describedby="emailHelp">
                            </div>
                            <div class="mb-3">
                                <label for="role" class="form-label">Role Pegawai</label>
                                <select class="form-control" name="role" id="role">
                                  <option>Pilih Role Pegawai</option>
                                  <option <?php echo e($employee->role == 'Tetap' ? "selected" : ''); ?> value="Tetap">Tetap</option>
                                  <option <?php echo e($employee->role == 'Training' ? "selected" : ''); ?> value="Training">Training</option>
                                  <option <?php echo e($employee->role == 'Freelance' ? "selected" : ''); ?> value="Freelance">Freelance</option>
                                </select>
                            </div>
                            <div class="<?php echo e($employee->kasbon != null ? 'mb-3' : 'mb-3 d-none'); ?>" id="input_kasbon">
                                <label for="kasbon" class="form-label">Nominal Maksimal Kasbon</label>
                                <input type="text" id="kasbon" value="<?php echo e($employee->kasbon); ?>" name="kasbon" class="form-control" id="kasbon" placeholder="Masukkan maksimal kasbon" aria-describedby="emailHelp">
                            </div>
                            <button type="submit" id="submit" class="btn btn-primary mt-3">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<input type="hidden" value="<?php echo e($employee->kasbon); ?>" id="returnKasbon">

<script>

$("#role").change(function (e) { 
        e.preventDefault();
        if ($("#role").val() == 'Tetap') {
            $("#input_kasbon").removeClass('d-none');
            $("#kasbon").val($("#returnKasbon").val());
        } else {
            $("#input_kasbon").addClass('d-none');
            $("#kasbon").val('');
        }
    });

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\project-commission\resources\views/admin/employeeEdit.blade.php ENDPATH**/ ?>