

<?php $__env->startSection('content'); ?>


<div class="page-content">
    <div class="main-wrapper">
        <div class="row">
            <div class="col">

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ul>
                                <li><?php echo e($error); ?></li>
                            </ul>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Edit Transaksi</h5>
                        <form action="/transaction/update/<?php echo e($transaction->id); ?>" method=post>
                            <?php echo csrf_field(); ?>
                            
                            <div class="form-group pb-1 input-daterange">
                              <label for="exampleInputEmail1"><b>Tanggal</b></label> <br>
                              <input style="width: 25%;" value="<?php echo e($transaction->created_at->format('Y-m-d')); ?>" class="form-control mt-2 mb-2" id="date" style="text-transform: uppercase;" aria-describedby="emailHelp" name="date" />
                            </div>
                            <div class="form-group pb-1">
                                <label for="exampleInputEmail1"><b>NO PLAT KENDARAAN</b></label> <br>
                                <input type="text" style="width: 100%;" value="<?php echo e($transaction->customer); ?>" class="form-control mt-2 mb-2" id="nopol" style="text-transform: uppercase;" aria-describedby="emailHelp" name="nopol" />
                            </div>
                              
                              <div class="row pt-1">
                                <label class="form-check-label mt-2" style="font-size: 15px" for="defaultCheck1"><b>LAYANAN</b></label>
                                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                                  <div class="form-group mt-1 col-md-6">
                                    <input class="form-check-input cbservice" 
                                    <?php if(in_array($service->id, $productArray)): ?>
                                        <?php echo e('checked'); ?>

                                    <?php endif; ?>
                                    data-commission="<?php echo e($service->commission_value); ?>" data-type="<?php echo e($service->type_commission); ?>" type="checkbox" name="service[]" onclick="services(<?php echo e($service->id); ?>)" value="<?php echo e($service->id); ?>" id="servicesCheckbox">
                                    <label class="form-check-label ps-2" style="font-size: 15px" for="defaultCheck1"><?php echo e($service->service); ?> (Rp <?php echo number_format($service->price,0,',','.'); ?>)</label>
                                  </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <label class="form-check-label mt-3" style="font-size: 15px" for="defaultCheck1"><b>LAYANAN BUNDLING</b></label>
                            
                                <?php
                                    $bundling_price = 0;
                                    $product_array = [];
                                    $bundleVal = 0;
                                ?>
                                <?php $__currentLoopData = $bundle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bundling): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-group col-md-6">
                                  <input class="form-check-input cbbundling" type="checkbox" name="bundlingsCheckbox[]" onclick="services(<?php echo e($bundling->id); ?>)" value="<?php echo e($bundling->id); ?>" id="bundlingsCheckbox">
                                  <label class="form-check-label ps-2" style="font-size: 15px" for="defaultCheck1"><?php echo e($bundling->name); ?> (Rp <?php echo number_format($bundling->total_price,0,',','.'); ?>)
                                    <?php $__currentLoopData = $bundling->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <ul style="margin-bottom: 0px !important">
                                      
                                      <input type="hidden" id="product_id" value="<?php echo e($item->id); ?>">
                                      <li><?php echo e($item->service); ?></li>
                                    </ul>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </label>
                                      </div>
                                      
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                            
                              <div class="row pt-2 pb-3" style="border-bottom: 1px solid #c5bebefa"> 
                                <label class="form-check-label mt-3" style="font-size: 15px" for="defaultCheck1"><b>PENGGARAP</b></label>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                                  <div class="form-group mt-1 col-md-6">
                                    <input class="form-check-input cbemployee"
                                    <?php if(in_array($employee->id, $employeeArray)): ?>
                                        <?php echo e('checked'); ?>

                                    <?php endif; ?>
                                    name="employee[]" type="checkbox" value="<?php echo e($employee->id); ?>" id="employee">
                                    <label class="form-check-label ps-2" style="font-size: 15px" for="defaultCheck1"><?php echo e($employee->name); ?></label>
                                  </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                              <div class="d-flex justify-content-between pt-2">
                                <div class="total"><b>Total Harga: </b></div>
                                <div id="amount" class="text-danger">Rp <?php echo number_format($transaction->total_price,0,',','.'); ?></div>
                            </div>
                            <input type="hidden" name="total_price" id="total_price" value="<?php echo e($transaction->total_price); ?>">
                            <input type="hidden" name="employee_detach" value="<?php echo e($employee_value); ?>">
                            <input type="hidden" name="product_detach" value="<?php echo e($product_value); ?>">
                            <button type="submit" id="submit" class="btn btn-primary mt-3">Submit</button>
                          </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<input type="hidden" name="old_nopol" id="old_nopol" value="<?php echo e($transaction->customer); ?>">

<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>


<script>

// var selectOption = {
//         placeholder: $("#old_nopol").val(),
//         minimumInputLength: 3,
//         allowClear: true,
//         tags:true,
//         theme: "bootstrap-5",
//         value: 'sss',
//         ajax: {
//             url:  "/transaction-select",
//             dataType: "json",
//             delay: 250,
//             type: "POST",
//             headers: {
//                 'X-CSRF-TOKEN': token,
//             },
//             data: function (params) {
//                 return {
//                     search: params.term,
//                     // branch_id: $('#branch_id').val(),
//                 };
//             },
//             processResults: function (data) {
//                 var select2Data = $.map(data, function (obj) {
//                     obj.id = obj.customer;
//                     obj.text = `${obj.customer}`;
//                     return obj;
//                 });
//                 return {
//                     results: select2Data,
//                 };
//             },
//             cache: true,
//         },
//     };

//     $('#nopol').select2(selectOption);

    // $(document).ready(function () {
    //     $(".select2-search__field")[0].val($("#old_nopol").val());
    // });

    $(document).ready(function () {
      
      $(".input-daterange").datepicker({
        todayBtn: 'linked',
        format: 'yyyy-mm-dd',
        autoclose: true, 
      });

    });

       
    console.log($("#nopol").data("select2").dropdown.$search.val($("#old_nopol").val()));

  function services(id) {


    var serviceArray = [];
    $(".cbservice:checkbox:checked").each(function () {
      serviceArray.push($(this).val());
    });


    if ($(".cbbundling:checkbox").is(':checked')) {
      console.log('not checked');
        var bundleArray = [];
        $(".cbbundling:checkbox:checked").each(function () {
          bundleArray.push($(this).val());
        });
        // var bundleVal = $(".cbbundling:checkbox:checked").val();
        // var bundleArray = bundleVal.split(',')
        // console.log(bundleArray);
      } else {
        console.log('checked');
        var bundleArray = [];
        // console.log(bundleArray);
      }

      console.log(bundleArray);



      $.ajaxSetup({
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
      $.ajax({
        type: "post",
        url: "/transaction-total",
        data: {
          serviceArray: serviceArray,
          bundling: bundleArray,
        },
        dataType: "json",
        success: function (response) {
          $("#amount").html(`Rp ${response.total_price.toLocaleString("id-ID")}`);
          $("#total_price").val(response.total_price);
          // if (serviceArray.length > 0) {
          // } else {
          //   $("#amount").html(`Rp 0`);
          // }
        }
      });
  } 


</script>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\project-commission\resources\views/admin/transactionEdit.blade.php ENDPATH**/ ?>